"""file_type_identifier — identify file types via magic bytes, extensions, and MIME."""
from .identifier import identify_file, identify_files, FileTypeResult

__all__ = ["identify_file", "identify_files", "FileTypeResult"]
__version__ = "1.0.0"
