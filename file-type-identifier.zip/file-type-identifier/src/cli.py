"""
file_type_identifier/src/cli.py
Command-line interface for the file type identifier.
"""

import argparse
import json
import sys
import os
from pathlib import Path

# Allow running from repo root or src/
sys.path.insert(0, str(Path(__file__).parent))

from identifier import identify_file, identify_files, CATEGORY_COLORS

# ANSI color codes
RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
CYAN   = "\033[36m"
GREEN  = "\033[32m"
YELLOW = "\033[33m"
RED    = "\033[31m"
MAGENTA= "\033[35m"
BLUE   = "\033[34m"
WHITE  = "\033[37m"

CATEGORY_ANSI: dict[str, str] = {
    "image":    "\033[92m",   # bright green
    "audio":    "\033[94m",   # bright blue
    "video":    "\033[95m",   # bright magenta
    "document": "\033[91m",   # bright red
    "archive":  "\033[93m",   # bright yellow
    "binary":   "\033[31m",   # red
    "code":     "\033[32m",   # green
    "markup":   "\033[36m",   # cyan
    "data":     "\033[35m",   # magenta
    "text":     "\033[37m",   # white
    "config":   "\033[33m",   # yellow
    "database": "\033[95m",   # bright magenta
    "font":     "\033[96m",   # bright cyan
    "disk":     "\033[94m",   # bright blue
    "package":  "\033[93m",   # bright yellow
    "unknown":  "\033[90m",   # dark gray
}


def _format_size(size: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def _color(text: str, category: str) -> str:
    code = CATEGORY_ANSI.get(category, "")
    return f"{code}{text}{RESET}"


def print_result(result, verbose: bool = False) -> None:
    color = CATEGORY_ANSI.get(result.category, "")
    method_color = DIM

    type_str  = f"{BOLD}{color}{result.type_name:<10}{RESET}"
    cat_str   = f"{color}[{result.category}]{RESET}"
    name_str  = f"{CYAN}{result.file_name}{RESET}"
    size_str  = f"{DIM}{_format_size(result.file_size)}{RESET}"
    desc_str  = f"{result.description}"

    print(f"  {type_str}  {cat_str:<20}  {name_str}  {size_str}")
    if verbose:
        print(f"           {DIM}Description : {RESET}{desc_str}")
        print(f"           {DIM}Method      : {RESET}{result.method}")
        if result.mime_type:
            print(f"           {DIM}MIME        : {RESET}{result.mime_type}")
        if result.extension:
            print(f"           {DIM}Extension   : {RESET}{result.extension}")
        print()


def cmd_identify(args) -> None:
    results = []
    errors  = []

    for path in args.files:
        try:
            r = identify_file(path)
            results.append(r)
        except (FileNotFoundError, ValueError, PermissionError) as e:
            errors.append((path, str(e)))

    if args.json:
        output = [r.to_dict() for r in results]
        print(json.dumps(output, indent=2))
        return

    print()
    print(f"  {BOLD}{'TYPE':<10}  {'CATEGORY':<20}  FILE{RESET}")
    print(f"  {'─'*10}  {'─'*20}  {'─'*40}")
    for r in results:
        print_result(r, verbose=args.verbose)

    if errors:
        print(f"\n  {RED}Errors:{RESET}")
        for path, msg in errors:
            print(f"    {DIM}{path}{RESET}: {RED}{msg}{RESET}")

    print(f"\n  {DIM}{len(results)} file(s) identified.{RESET}\n")


def cmd_scan(args) -> None:
    """Scan a directory and summarize file types."""
    directory = Path(args.directory)
    if not directory.is_dir():
        print(f"{RED}Error: {args.directory!r} is not a directory.{RESET}")
        sys.exit(1)

    pattern = "**/*" if args.recursive else "*"
    paths = [str(p) for p in directory.glob(pattern) if p.is_file()]

    if not paths:
        print(f"{YELLOW}No files found in {args.directory!r}{RESET}")
        return

    results = identify_files(paths)

    if args.json:
        print(json.dumps([r.to_dict() for r in results], indent=2))
        return

    # Summary
    from collections import Counter
    cat_count = Counter(r.category for r in results)
    type_count = Counter(r.type_name for r in results)

    print(f"\n  {BOLD}Scan: {CYAN}{args.directory}{RESET}  {DIM}({len(results)} files){RESET}\n")
    print(f"  {BOLD}By Category:{RESET}")
    for cat, count in cat_count.most_common():
        bar = "█" * min(count, 40)
        color = CATEGORY_ANSI.get(cat, "")
        print(f"    {color}{cat:<12}{RESET}  {color}{bar}{RESET} {count}")

    print(f"\n  {BOLD}Top File Types:{RESET}")
    for type_name, count in type_count.most_common(10):
        print(f"    {CYAN}{type_name:<12}{RESET}  {count}")

    print()


def main():
    parser = argparse.ArgumentParser(
        prog="filetype",
        description="🔍 File Type Identifier — detect file types via magic bytes & extensions",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  filetype identify photo.jpg document.pdf archive.zip
  filetype identify --verbose --json report.pdf
  filetype scan ./my-folder
  filetype scan ./my-folder --recursive
        """,
    )
    parser.add_argument("--version", action="version", version="filetype 1.0.0")

    subparsers = parser.add_subparsers(dest="command")

    # identify
    p_id = subparsers.add_parser("identify", aliases=["id", "i"],
                                  help="Identify one or more files")
    p_id.add_argument("files", nargs="+", metavar="FILE", help="Files to identify")
    p_id.add_argument("-v", "--verbose", action="store_true", help="Show detailed info")
    p_id.add_argument("--json", action="store_true", help="Output as JSON")
    p_id.set_defaults(func=cmd_identify)

    # scan
    p_sc = subparsers.add_parser("scan", aliases=["s"],
                                  help="Scan a directory and summarize file types")
    p_sc.add_argument("directory", metavar="DIR", help="Directory to scan")
    p_sc.add_argument("-r", "--recursive", action="store_true",
                      help="Scan subdirectories recursively")
    p_sc.add_argument("--json", action="store_true", help="Output as JSON")
    p_sc.set_defaults(func=cmd_scan)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
