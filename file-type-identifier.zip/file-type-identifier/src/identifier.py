"""
file_type_identifier/src/identifier.py
Core logic for identifying file types via magic bytes, extensions, and MIME types.
"""

import os
import mimetypes
import struct
from pathlib import Path
from typing import Optional

# Magic byte signatures: (offset, bytes) -> (type_name, category, description)
MAGIC_SIGNATURES: list[tuple[int, bytes, str, str, str]] = [
    # Images
    (0, b'\xff\xd8\xff',                "JPEG",   "image",    "JPEG Image"),
    (0, b'\x89PNG\r\n\x1a\n',          "PNG",    "image",    "PNG Image"),
    (0, b'GIF87a',                       "GIF",    "image",    "GIF Image (87a)"),
    (0, b'GIF89a',                       "GIF",    "image",    "GIF Image (89a)"),
    (0, b'BM',                           "BMP",    "image",    "Bitmap Image"),
    (0, b'RIFF',                         "WEBP",   "image",    "WebP Image (RIFF container)"),
    (0, b'\x00\x00\x01\x00',            "ICO",    "image",    "Windows Icon"),
    (0, b'II*\x00',                      "TIFF",   "image",    "TIFF Image (little-endian)"),
    (0, b'MM\x00*',                      "TIFF",   "image",    "TIFF Image (big-endian)"),

    # Documents
    (0, b'%PDF',                         "PDF",    "document", "PDF Document"),
    (0, b'PK\x03\x04',                   "ZIP",    "archive",  "ZIP Archive / Office Open XML"),
    (0, b'\xd0\xcf\x11\xe0',            "OLE",    "document", "Microsoft OLE (doc/xls/ppt)"),
    (0, b'{\\rtf',                        "RTF",    "document", "Rich Text Format"),

    # Audio
    (0, b'ID3',                          "MP3",    "audio",    "MP3 Audio (ID3 tag)"),
    (0, b'\xff\xfb',                     "MP3",    "audio",    "MP3 Audio"),
    (0, b'fLaC',                         "FLAC",   "audio",    "FLAC Audio"),
    (0, b'OggS',                         "OGG",    "audio",    "Ogg Container (audio/video)"),
    (0, b'RIFF',                         "WAV",    "audio",    "WAV Audio (RIFF container)"),

    # Video
    (4, b'ftyp',                         "MP4",    "video",    "MP4 Video"),
    (0, b'\x1aE\xdf\xa3',               "MKV",    "video",    "Matroska Video"),
    (0, b'FLV',                          "FLV",    "video",    "Flash Video"),

    # Executables & Binaries
    (0, b'MZ',                           "EXE",    "binary",   "Windows Executable / DLL"),
    (0, b'\x7fELF',                      "ELF",    "binary",   "ELF Executable (Linux/Unix)"),
    (0, b'\xfe\xed\xfa\xce',            "MACHO",  "binary",   "Mach-O Executable (32-bit)"),
    (0, b'\xfe\xed\xfa\xcf',            "MACHO",  "binary",   "Mach-O Executable (64-bit)"),

    # Archives
    (0, b'\x1f\x8b',                     "GZIP",   "archive",  "Gzip Archive"),
    (0, b'BZh',                          "BZIP2",  "archive",  "Bzip2 Archive"),
    (0, b'\xfd7zXZ\x00',                "XZ",     "archive",  "XZ Archive"),
    (0, b'7z\xbc\xaf\x27\x1c',          "7ZIP",   "archive",  "7-Zip Archive"),
    (0, b'Rar!\x1a\x07',                "RAR",    "archive",  "RAR Archive"),
    (0, b'ustar',                        "TAR",    "archive",  "TAR Archive"),

    # Fonts
    (0, b'\x00\x01\x00\x00',            "TTF",    "font",     "TrueType Font"),
    (0, b'OTTO',                         "OTF",    "font",     "OpenType Font"),
    (0, b'wOFF',                         "WOFF",   "font",     "WOFF Font"),
    (0, b'wOF2',                         "WOFF2",  "font",     "WOFF2 Font"),

    # Data / DB
    (0, b'SQLite format 3\x00',          "SQLITE", "database", "SQLite Database"),

    # Scripts / Text (UTF BOM)
    (0, b'\xef\xbb\xbf',                "UTF8",   "text",     "UTF-8 BOM Text"),
    (0, b'\xff\xfe',                     "UTF16LE","text",     "UTF-16 LE Text"),
    (0, b'\xfe\xff',                     "UTF16BE","text",     "UTF-16 BE Text"),
]

# Extension-based fallback map
EXTENSION_MAP: dict[str, tuple[str, str, str]] = {
    # Text / Code
    ".py":    ("Python",      "code",     "Python Source File"),
    ".js":    ("JavaScript",  "code",     "JavaScript Source File"),
    ".ts":    ("TypeScript",  "code",     "TypeScript Source File"),
    ".jsx":   ("JSX",         "code",     "React JSX Component"),
    ".tsx":   ("TSX",         "code",     "React TSX Component"),
    ".html":  ("HTML",        "markup",   "HTML Document"),
    ".htm":   ("HTML",        "markup",   "HTML Document"),
    ".css":   ("CSS",         "code",     "CSS Stylesheet"),
    ".scss":  ("SCSS",        "code",     "SCSS Stylesheet"),
    ".sass":  ("Sass",        "code",     "Sass Stylesheet"),
    ".json":  ("JSON",        "data",     "JSON Data File"),
    ".yaml":  ("YAML",        "data",     "YAML Data File"),
    ".yml":   ("YAML",        "data",     "YAML Data File"),
    ".toml":  ("TOML",        "data",     "TOML Configuration File"),
    ".xml":   ("XML",         "markup",   "XML Document"),
    ".md":    ("Markdown",    "text",     "Markdown Document"),
    ".rst":   ("RST",         "text",     "reStructuredText Document"),
    ".txt":   ("Plain Text",  "text",     "Plain Text File"),
    ".csv":   ("CSV",         "data",     "Comma-Separated Values"),
    ".tsv":   ("TSV",         "data",     "Tab-Separated Values"),
    ".ini":   ("INI",         "config",   "INI Configuration File"),
    ".cfg":   ("Config",      "config",   "Configuration File"),
    ".env":   ("Dotenv",      "config",   ".env Configuration File"),
    ".sh":    ("Shell",       "code",     "Shell Script"),
    ".bash":  ("Bash",        "code",     "Bash Script"),
    ".zsh":   ("Zsh",         "code",     "Zsh Script"),
    ".bat":   ("Batch",       "code",     "Windows Batch Script"),
    ".ps1":   ("PowerShell",  "code",     "PowerShell Script"),
    ".rb":    ("Ruby",        "code",     "Ruby Source File"),
    ".php":   ("PHP",         "code",     "PHP Source File"),
    ".java":  ("Java",        "code",     "Java Source File"),
    ".kt":    ("Kotlin",      "code",     "Kotlin Source File"),
    ".swift": ("Swift",       "code",     "Swift Source File"),
    ".go":    ("Go",          "code",     "Go Source File"),
    ".rs":    ("Rust",        "code",     "Rust Source File"),
    ".c":     ("C",           "code",     "C Source File"),
    ".cpp":   ("C++",         "code",     "C++ Source File"),
    ".cc":    ("C++",         "code",     "C++ Source File"),
    ".h":     ("C Header",    "code",     "C/C++ Header File"),
    ".cs":    ("C#",          "code",     "C# Source File"),
    ".r":     ("R",           "code",     "R Script"),
    ".lua":   ("Lua",         "code",     "Lua Script"),
    ".sql":   ("SQL",         "code",     "SQL Script"),
    # Images
    ".svg":   ("SVG",         "image",    "Scalable Vector Graphic"),
    ".heic":  ("HEIC",        "image",    "High Efficiency Image (Apple)"),
    # Other
    ".iso":   ("ISO",         "disk",     "Optical Disk Image"),
    ".dmg":   ("DMG",         "disk",     "macOS Disk Image"),
    ".apk":   ("APK",         "package",  "Android App Package"),
    ".ipa":   ("IPA",         "package",  "iOS App Archive"),
    ".deb":   ("DEB",         "package",  "Debian Package"),
    ".rpm":   ("RPM",         "package",  "RPM Package"),
}

CATEGORY_COLORS: dict[str, str] = {
    "image":    "#6EE7B7",
    "audio":    "#93C5FD",
    "video":    "#C4B5FD",
    "document": "#FCA5A5",
    "archive":  "#FCD34D",
    "binary":   "#F87171",
    "code":     "#86EFAC",
    "markup":   "#A5F3FC",
    "data":     "#FDA4AF",
    "text":     "#E5E7EB",
    "config":   "#FDE68A",
    "database": "#F9A8D4",
    "font":     "#DDD6FE",
    "disk":     "#BAE6FD",
    "package":  "#FDBA74",
    "unknown":  "#9CA3AF",
}


class FileTypeResult:
    """Holds the result of a file type identification."""

    def __init__(
        self,
        file_name: str,
        file_size: int,
        type_name: str,
        category: str,
        description: str,
        method: str,
        mime_type: Optional[str] = None,
        extension: Optional[str] = None,
    ):
        self.file_name = file_name
        self.file_size = file_size
        self.type_name = type_name
        self.category = category
        self.description = description
        self.method = method          # "magic", "extension", "mime", "unknown"
        self.mime_type = mime_type
        self.extension = extension
        self.color = CATEGORY_COLORS.get(category, CATEGORY_COLORS["unknown"])

    def to_dict(self) -> dict:
        return {
            "file_name": self.file_name,
            "file_size": self.file_size,
            "type_name": self.type_name,
            "category": self.category,
            "description": self.description,
            "method": self.method,
            "mime_type": self.mime_type,
            "extension": self.extension,
            "color": self.color,
        }

    def __repr__(self) -> str:
        return (
            f"FileTypeResult(name={self.file_name!r}, type={self.type_name!r}, "
            f"category={self.category!r}, method={self.method!r})"
        )


def _read_header(path: str, size: int = 512) -> bytes:
    """Read the first `size` bytes of a file."""
    with open(path, "rb") as f:
        return f.read(size)


def identify_by_magic(header: bytes) -> Optional[tuple[str, str, str]]:
    """Return (type_name, category, description) from magic bytes, or None."""
    for offset, magic, type_name, category, description in MAGIC_SIGNATURES:
        if header[offset: offset + len(magic)] == magic:
            # Disambiguate RIFF: WAV vs WEBP
            if magic == b'RIFF' and len(header) >= 12:
                sub = header[8:12]
                if sub == b'WEBP':
                    return "WEBP", "image", "WebP Image"
                elif sub == b'WAVE':
                    return "WAV", "audio", "WAV Audio"
                continue
            return type_name, category, description
    return None


def identify_by_extension(ext: str) -> Optional[tuple[str, str, str]]:
    """Return (type_name, category, description) from file extension, or None."""
    return EXTENSION_MAP.get(ext.lower())


def identify_file(path: str) -> FileTypeResult:
    """
    Identify the type of a file using magic bytes, then extension fallback.

    Parameters
    ----------
    path : str
        Absolute or relative path to the file.

    Returns
    -------
    FileTypeResult
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not p.is_file():
        raise ValueError(f"Path is not a file: {path}")

    file_size = p.stat().st_size
    extension = p.suffix  # e.g. ".png"
    mime_type, _ = mimetypes.guess_type(str(p))

    # 1. Magic bytes
    try:
        header = _read_header(str(p))
        result = identify_by_magic(header)
        if result:
            return FileTypeResult(
                file_name=p.name,
                file_size=file_size,
                type_name=result[0],
                category=result[1],
                description=result[2],
                method="magic",
                mime_type=mime_type,
                extension=extension,
            )
    except (IOError, PermissionError):
        pass

    # 2. Extension fallback
    if extension:
        result = identify_by_extension(extension)
        if result:
            return FileTypeResult(
                file_name=p.name,
                file_size=file_size,
                type_name=result[0],
                category=result[1],
                description=result[2],
                method="extension",
                mime_type=mime_type,
                extension=extension,
            )

    # 3. MIME type fallback
    if mime_type:
        broad_category = mime_type.split("/")[0]
        return FileTypeResult(
            file_name=p.name,
            file_size=file_size,
            type_name=mime_type.split("/")[-1].upper(),
            category=broad_category if broad_category in CATEGORY_COLORS else "unknown",
            description=f"File identified by MIME: {mime_type}",
            method="mime",
            mime_type=mime_type,
            extension=extension,
        )

    # 4. Unknown
    return FileTypeResult(
        file_name=p.name,
        file_size=file_size,
        type_name="Unknown",
        category="unknown",
        description="Could not determine file type",
        method="unknown",
        mime_type=None,
        extension=extension,
    )


def identify_files(paths: list[str]) -> list[FileTypeResult]:
    """Identify multiple files and return a list of results."""
    return [identify_file(p) for p in paths]
