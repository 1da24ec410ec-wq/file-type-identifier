"""
tests/test_identifier.py
Unit tests for the file type identifier.
"""

import os
import sys
import struct
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from identifier import (
    identify_file,
    identify_by_magic,
    identify_by_extension,
    FileTypeResult,
    MAGIC_SIGNATURES,
    EXTENSION_MAP,
)


def _make_tmp(content: bytes, suffix: str = ".bin") -> str:
    """Write bytes to a temp file and return its path."""
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "wb") as f:
        f.write(content)
    return path


class TestMagicIdentification(unittest.TestCase):

    def test_png(self):
        header = b'\x89PNG\r\n\x1a\n' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "PNG")
        self.assertEqual(result[1], "image")

    def test_jpeg(self):
        header = b'\xff\xd8\xff' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "JPEG")

    def test_pdf(self):
        header = b'%PDF-1.7\n' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "PDF")
        self.assertEqual(result[1], "document")

    def test_gzip(self):
        header = b'\x1f\x8b' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "GZIP")
        self.assertEqual(result[1], "archive")

    def test_zip(self):
        header = b'PK\x03\x04' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "ZIP")

    def test_elf(self):
        header = b'\x7fELF' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "ELF")
        self.assertEqual(result[1], "binary")

    def test_unknown_returns_none(self):
        header = b'\x00\x00\x00\x00' * 20
        result = identify_by_magic(header)
        self.assertIsNone(result)

    def test_webp_disambiguation(self):
        header = b'RIFF' + b'\x00\x00\x00\x00' + b'WEBP' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "WEBP")
        self.assertEqual(result[1], "image")

    def test_wav_disambiguation(self):
        header = b'RIFF' + b'\x00\x00\x00\x00' + b'WAVE' + b'\x00' * 100
        result = identify_by_magic(header)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "WAV")
        self.assertEqual(result[1], "audio")


class TestExtensionIdentification(unittest.TestCase):

    def test_python(self):
        result = identify_by_extension(".py")
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "Python")
        self.assertEqual(result[1], "code")

    def test_json(self):
        result = identify_by_extension(".json")
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "JSON")
        self.assertEqual(result[1], "data")

    def test_case_insensitive(self):
        result_lower = identify_by_extension(".py")
        result_upper = identify_by_extension(".PY")
        self.assertEqual(result_lower, result_upper)

    def test_unknown_extension(self):
        result = identify_by_extension(".xyzzy123")
        self.assertIsNone(result)

    def test_markdown(self):
        result = identify_by_extension(".md")
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "Markdown")


class TestIdentifyFile(unittest.TestCase):

    def _make(self, content: bytes, suffix: str = ".bin") -> str:
        return _make_tmp(content, suffix)

    def tearDown(self):
        pass  # Temp files are cleaned up per-test

    def test_identify_png_by_magic(self):
        path = self._make(b'\x89PNG\r\n\x1a\n' + b'\x00' * 200, ".png")
        try:
            r = identify_file(path)
            self.assertEqual(r.type_name, "PNG")
            self.assertEqual(r.method, "magic")
        finally:
            os.unlink(path)

    def test_identify_py_by_extension(self):
        path = self._make(b'print("hello")\n', ".py")
        try:
            r = identify_file(path)
            self.assertEqual(r.type_name, "Python")
            self.assertEqual(r.method, "extension")
        finally:
            os.unlink(path)

    def test_file_not_found_raises(self):
        with self.assertRaises(FileNotFoundError):
            identify_file("/nonexistent/path/file.txt")

    def test_result_has_size(self):
        content = b"hello world"
        path = self._make(content, ".txt")
        try:
            r = identify_file(path)
            self.assertEqual(r.file_size, len(content))
        finally:
            os.unlink(path)

    def test_unknown_file(self):
        path = self._make(b'\x00\x01\x02\x03', ".xyzunknown999")
        try:
            r = identify_file(path)
            self.assertEqual(r.category, "unknown")
        finally:
            os.unlink(path)

    def test_to_dict(self):
        path = self._make(b'\x89PNG\r\n\x1a\n' + b'\x00' * 200, ".png")
        try:
            r = identify_file(path)
            d = r.to_dict()
            self.assertIn("type_name", d)
            self.assertIn("category", d)
            self.assertIn("description", d)
            self.assertIn("method", d)
            self.assertIn("color", d)
        finally:
            os.unlink(path)

    def test_magic_takes_priority_over_extension(self):
        # A PNG file with a .txt extension — magic should win
        path = self._make(b'\x89PNG\r\n\x1a\n' + b'\x00' * 200, ".txt")
        try:
            r = identify_file(path)
            self.assertEqual(r.type_name, "PNG")
            self.assertEqual(r.method, "magic")
        finally:
            os.unlink(path)


class TestResultRepr(unittest.TestCase):

    def test_repr(self):
        path = _make_tmp(b'\x89PNG\r\n\x1a\n' + b'\x00' * 200, ".png")
        try:
            r = identify_file(path)
            s = repr(r)
            self.assertIn("PNG", s)
            self.assertIn("image", s)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
